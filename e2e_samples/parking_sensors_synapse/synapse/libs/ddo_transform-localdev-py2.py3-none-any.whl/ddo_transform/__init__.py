# -*- coding: utf-8 -*-

"""Top-level package for ddo_transform."""

__author__ = """Lace Lofranco"""
__email__ = 'lace.lofranco@microsoft.com'
__version__ = '1.0.0'
